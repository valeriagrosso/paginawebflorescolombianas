let parrafo1 = document.querySelector("#parrafo1")
let boton1O = document.querySelector("#boton1O")
let boton1M = document.querySelector("#boton1M")
function ocultarParrafo1 (){
    parrafo1.style.visibility = "hidden";
}
boton1O.onclick = ocultarParrafo1;
function mostrarParrafo1(){
    parrafo1.style.visibility = "visible";
}
boton1M.onclick =mostrarParrafo1;
let parrafo2 = document.querySelector("#parrafo2")
let boton2O = document.querySelector("#boton2O")
let boton2M = document.querySelector("#boton2M")
function ocultarParrafo2 (){
    parrafo2.style.visibility = "hidden";
}
boton2O.onclick = ocultarParrafo2;
function mostrarParrafo2(){
    parrafo2.style.visibility = "visible";
}
boton2M.onclick =mostrarParrafo2;
let parrafo3 = document.querySelector("#parrafo3")
let boton3O = document.querySelector("#boton3O")
let boton3M = document.querySelector("#boton3M")
function ocultarParrafo3 (){
    parrafo3.style.visibility = "hidden";
}
boton3O.onclick = ocultarParrafo3;
function mostrarParrafo3(){
    parrafo3.style.visibility = "visible";
}
boton3M.onclick =mostrarParrafo3;
let parrafo4 = document.querySelector("#parrafo4")
let boton4O = document.querySelector("#boton4O")
let boton4M = document.querySelector("#boton4M")
function ocultarParrafo4 (){
    parrafo4.style.visibility = "hidden";
}
boton4O.onclick = ocultarParrafo4;
function mostrarParrafo4(){
    parrafo4.style.visibility = "visible";
}
boton4M.onclick =mostrarParrafo4;

let parrafo5 = document.querySelector("#parrafo5")
let boton5C = document.querySelector("#boton5C")
function cambiarColor5(){
    parrafo5.style.backgroundColor = "red";
}
boton5C.onclick = cambiarColor5;
let parrafo6 = document.querySelector("#parrafo6")
let boton6C = document.querySelector("#boton6C")
function cambiarColor6(){
    parrafo6.style.backgroundColor = "blue";
}
boton6C.onclick = cambiarColor6;

let parrafo7 = document.querySelector("#parrafo7")
let boton7O = document.querySelector("#boton7O")
let boton7M = document.querySelector("#boton7M")
function ocultarParrafo7 (){
    parrafo7.style.visibility = "hidden";
}
boton7O.onclick = ocultarParrafo7;
function mostrarParrafo7(){
    parrafo7.style.visibility = "visible";
}
boton7M.onclick =mostrarParrafo7;
let parrafo8 = document.querySelector("#parrafo8")
let boton8O = document.querySelector("#boton8O")
let boton8M = document.querySelector("#boton8M")
function ocultarParrafo8 (){
    parrafo8.style.visibility = "hidden";
}
boton8O.onclick = ocultarParrafo8;
function mostrarParrafo8(){
    parrafo8.style.visibility = "visible";
}
boton8M.onclick =mostrarParrafo8;

let parrafo9 = document.querySelector("#parrafo9")
let boton9C = document.querySelector("#boton9C")
function cambiarColor9(){
    parrafo9.style.backgroundColor = "purple";
}
boton9C.onclick = cambiarColor9;

let parrafo10 = document.querySelector("#parrafo10")
let boton10O = document.querySelector("#boton10O")
let boton10M = document.querySelector("#boton10M")
function ocultarParrafo10 (){
    parrafo10.style.visibility = "hidden";
}
boton10O.onclick = ocultarParrafo10;
function mostrarParrafo10(){
    parrafo10.style.visibility = "visible";
}
boton10M.onclick =mostrarParrafo10;
let parrafo11 = document.querySelector("#parrafo11")
let boton11O = document.querySelector("#boton11O")
let boton11M = document.querySelector("#boton11M")
function ocultarParrafo11 (){
    parrafo11.style.visibility = "hidden";
}
boton11O.onclick = ocultarParrafo11;
function mostrarParrafo11(){
    parrafo11.style.visibility = "visible";
}
boton11M.onclick =mostrarParrafo11;